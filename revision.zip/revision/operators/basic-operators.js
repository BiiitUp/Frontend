// Basic Operators
// Addition
var a = 10;
var b = 20;
var c = a + b;
console.log(c);
// Subtraction
var d = a - b;
console.log(d)
// Multiplication
var e = a * b;
console.log(e)
// Division
var f = a / b; // 100/200 = 0.5
console.log(f)
// Modulus
var z = 9;
var y = 2
var g = z % y;
console.log(g)
// Increment
g++;
console.log(g)
// Decrement
g--;
console.log(g)

// Comparison Operators
// Logical Operators && || !
// Bitwise Operators & | ^ ~ << >> >>>
