// let, var and const

let name = "Praveen" // block scope
var rollNumber = 'R141692' // function scope
const EMAIL = 'info@biiitup.com' // constant

console.log(name)
console.log(rollNumber)
console.log(EMAIL)
